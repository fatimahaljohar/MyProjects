/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package final_exam;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

/**
 *
 * @author fatim
 */
public class MyFrame extends JFrame implements ItemListener{
    JLabel l1=new JLabel("Convert From");
    JLabel l2=new JLabel("Enter Numeric Temperature");
    JLabel l3=new JLabel("Comparaple Tempreture is");
     JLabel l4=new JLabel("Convert To");
    JTextField f1=new JTextField(25);
    JTextField f2=new JTextField(25);
    JRadioButton r1=new JRadioButton("Fahrenheit");
    JRadioButton r2=new JRadioButton("Celcius");
    JRadioButton r3=new JRadioButton("Kalvin");
    JRadioButton r4=new JRadioButton("Fahrenheit");
    JRadioButton r5=new JRadioButton("Celcius");
    JRadioButton r6=new JRadioButton("Kalvin");
    ButtonGroup bg=new ButtonGroup();
     ButtonGroup bg2=new ButtonGroup();
    JPanel p1=new JPanel();
    JPanel p2=new JPanel();
    JPanel p3=new JPanel();
    JPanel p4=new JPanel();
    JPanel p5=new JPanel();
    JPanel p6=new JPanel();
    JPanel p7=new JPanel();
    JPanel p8=new JPanel();
    JPanel p9=new JPanel();
    JPanel p10=new JPanel();
    
    
   public MyFrame(){
       super("TempratureConversion");
       setLayout (new FlowLayout());
       p9.setLayout(new GridLayout(9,1));
       p1.add(l1);
       p9.add(p1);
       
       bg.add(r1);
       bg.add(r2);
       bg.add(r3);
       p2.add(r1);
       p2.add(r2);
       p2.add(r3);
      p9.add(p2);
      
      p3.add(l2);
     p9. add(p3);
      
      p4.add(f1);
      p9.add(p4);
      
      p5.add(l4);
      p9.add(p5);
      
        p6.add(l4);
     p9. add(p6);
     
     bg2.add(r4);
       bg2.add(r5);
       bg2.add(r6);
      p7.add(r4);
      p7.add(r5);
      p7.add(r6);
      p9.add(p7);
      
     p8.add(l3);
     p9. add(p8);
     
      p10.add(f2);
      p9.add(p10);
      add(p9);
      
      r1.addItemListener(this);
      r2.addItemListener(this);
      r3.addItemListener(this);
      r4.addItemListener(this);
      r5.addItemListener(this);
      r6.addItemListener(this);
   } 

    @Override
    public void itemStateChanged(ItemEvent ie) {
        
        if(r1.isSelected() && r4.isSelected()){
        double num1=Double.parseDouble(f1.getText());
        f2.setText(Double.toString(num1));
        }
        
        if(r1.isSelected() && r5.isSelected()){
        double num2=Double.parseDouble(f1.getText());
        double s=5/9*(num2-32);
        f2.setText(Double.toString(s));
        }
        if(r2.isSelected() && r4.isSelected()){
        double num3=Double.parseDouble(f1.getText());
        double s2=9/5*(num3+32);
        f2.setText(Double.toString(s2));
        }
         if(r2.isSelected() && r5.isSelected()){
        double num4=Double.parseDouble(f1.getText());
        f2.setText(Double.toString(num4));
        }
         
          if(r2.isSelected() && r6.isSelected()){
        double num5=Double.parseDouble(f1.getText());
        double s3=num5+273.15;
        f2.setText(Double.toString(s3));
        }
        
           if(r3.isSelected() && r6.isSelected()){
        double num6=Double.parseDouble(f1.getText());
        f2.setText(Double.toString(num6));
        }
       if(r3.isSelected() && r5.isSelected()){
        double num7=Double.parseDouble(f1.getText());
        double s4=num7-273.15;
        f2.setText(Double.toString(s4));
        }  
    }
}
